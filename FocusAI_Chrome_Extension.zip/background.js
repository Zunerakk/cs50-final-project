
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer YOUR_OPENAI_API_KEY_HERE',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: `Is this URL productive? ${tab.url}` }]
        })
      });
      const data = await response.json();
      const aiReply = data.choices[0].message.content.toLowerCase();
      if (aiReply.includes('not productive')) {
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: () => {
            document.body.innerHTML = "<h1 style='color:red;text-align:center;margin-top:20%'>Stay focused!</h1>";
          }
        });
      }
    } catch (err) {
      console.error('AI API error:', err);
    }
  }
});
