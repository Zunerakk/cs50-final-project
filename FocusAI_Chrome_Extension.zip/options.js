
document.getElementById('save').addEventListener('click', () => {
  const hours = document.getElementById('hours').value;
  chrome.storage.sync.set({ focusHours: hours }, () => {
    alert('Focus hours saved: ' + hours);
  });
});
