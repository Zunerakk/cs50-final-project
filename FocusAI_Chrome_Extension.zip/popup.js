
document.getElementById('motivate').addEventListener('click', async () => {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer YOUR_OPENAI_API_KEY_HERE',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'Give me a short motivational quote for focus.' }]
      })
    });
    const data = await response.json();
    alert(data.choices[0].message.content);
  } catch (err) {
    alert('Error fetching motivation');
    console.error(err);
  }
});
